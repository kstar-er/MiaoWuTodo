# All of these images are from the public domain.

I do not own any of these images. They are all from the public domain. If you are the owner of any of these images and would like them removed, please contact me or open a pull request to remove the image and I will remove them immediately.